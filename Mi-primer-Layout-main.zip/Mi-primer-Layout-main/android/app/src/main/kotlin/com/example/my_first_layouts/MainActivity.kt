package com.example.my_first_layouts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
